"""Fail-open helpers for runtime."""

# Reserved for future expansion.
