"""Public API contract."""

# Reserved for future stable public API.
