"""Evidence / logging namespace."""
