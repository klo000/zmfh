"""Public safety contract helpers."""

# Reserved for future stable public API.
