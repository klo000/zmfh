"""Managed module helpers."""

# Reserved for future expansion.
