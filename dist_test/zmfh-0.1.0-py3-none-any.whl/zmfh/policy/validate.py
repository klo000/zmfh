"""Policy validation.

Validation is fail-open:
- invalid policy => None
"""

from __future__ import annotations

from typing import Any, Optional

from zmfh.policy.model import Policy
from zmfh.runtime.modes import Mode


def _as_str_list(v: Any) -> Optional[list[str]]:
    if v is None:
        return []
    if isinstance(v, list) and all(isinstance(x, str) for x in v):
        return [x.strip() for x in v if x.strip()]
    return None


def validate_policy_dict(data: Any) -> Optional[Policy]:
    if not isinstance(data, dict):
        return None

    try:
        mode = Mode.from_text(data.get("mode"))
        managed_prefixes = _as_str_list(data.get("managed_prefixes"))
        if managed_prefixes is None:
            return None

        allow_loose_top_level = bool(data.get("allow_loose_top_level", True))
        raise_on_ambiguous = bool(data.get("raise_on_ambiguous", False))
        raise_on_deleted = bool(data.get("raise_on_deleted", True))

        exclude_dirs = _as_str_list(data.get("exclude_dirs"))
        if exclude_dirs is None:
            return None

        roots = _as_str_list(data.get("roots"))
        if roots is None:
            return None

        max_scan_files = data.get("max_scan_files")
        if max_scan_files is None:
            max_scan_files = Policy().max_scan_files
        if not isinstance(max_scan_files, int) or max_scan_files <= 0:
            return None

        cache_enabled = bool(data.get("cache_enabled", True))

        return Policy(
            mode=mode,
            managed_prefixes=managed_prefixes,
            allow_loose_top_level=allow_loose_top_level,
            raise_on_ambiguous=raise_on_ambiguous,
            raise_on_deleted=raise_on_deleted,
            exclude_dirs=exclude_dirs,
            max_scan_files=max_scan_files,
            roots=roots,
            cache_enabled=cache_enabled,
        )
    except Exception:
        return None
