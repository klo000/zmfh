"""Rules helpers."""

# Reserved for future expansion.
