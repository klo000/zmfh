"""Policy loading."""

from __future__ import annotations

from zmfh.policy.model import Policy
from zmfh.policy.validate import validate_policy_dict
from zmfh.util.jsonx import load_json


def load_policy(path: str, *, fallback: Policy) -> Policy:
    try:
        data = load_json(path)
        p = validate_policy_dict(data)
        return p if p is not None else fallback
    except Exception:
        return fallback
