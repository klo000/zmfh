"""Doctor checks."""

from __future__ import annotations

import sys
from dataclasses import dataclass

from zmfh.runtime.state import get_state


@dataclass(frozen=True)
class Check:
    name: str
    ok: bool
    msg: str


def check_python() -> Check:
    return Check(name="python", ok=True, msg=f"{sys.version.split()[0]} ({sys.executable})")


def check_disabled() -> Check:
    s = get_state()
    disabled = getattr(s, "disabled", False)
    return Check(name="disabled", ok=(not disabled), msg=f"disabled={disabled}")


def check_hook_installed() -> Check:
    s = get_state()
    ok = getattr(s, "hook_installed", False)
    return Check(name="hook_installed", ok=ok, msg=f"hook_installed={ok}")
