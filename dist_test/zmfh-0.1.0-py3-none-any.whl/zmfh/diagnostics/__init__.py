"""Diagnostics namespace."""
