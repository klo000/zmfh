"""CLI namespace."""
