"""ZMFH CLI entrypoint."""

from __future__ import annotations

import argparse

from zmfh.cli.doctor import cmd_doctor


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="zmfh")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("doctor", help="Show health / configuration report")

    args = parser.parse_args(argv)

    if args.cmd == "doctor":
        return cmd_doctor()

    return 1
