"""Event sinks."""

from __future__ import annotations

import sys
from dataclasses import asdict
from typing import Protocol

from zmfh.evidence.events import Event


class Sink(Protocol):
    def write(self, ev: Event) -> None: ...


class NullSink:
    def write(self, ev: Event) -> None:
        return


class StderrSink:
    def write(self, ev: Event) -> None:
        try:
            d = asdict(ev)
            kind = d.get("kind")
            outcome = d.get("outcome")
            name = d.get("fullname") or "-"
            print(f"[ZMFH][{kind}] {name} -> {outcome}", file=sys.stderr)
        except Exception:
            return
