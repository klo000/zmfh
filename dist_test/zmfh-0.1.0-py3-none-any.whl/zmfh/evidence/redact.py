"""Redaction helpers."""

# Reserved for future expansion.
