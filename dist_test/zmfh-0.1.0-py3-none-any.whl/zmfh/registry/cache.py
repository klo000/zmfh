"""In-memory resolution cache."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

from zmfh.registry.fingerprint import Fingerprint
from zmfh.registry.scan import Candidate


@dataclass(frozen=True)
class Cached:
    candidate: Candidate
    fp: Optional[Fingerprint]


_CACHE: Dict[str, Cached] = {}


def get(fullname: str) -> Optional[Cached]:
    return _CACHE.get(fullname)


def put(fullname: str, entry: Cached) -> None:
    _CACHE[fullname] = entry


def drop(fullname: str) -> None:
    _CACHE.pop(fullname, None)


def clear() -> None:
    _CACHE.clear()
