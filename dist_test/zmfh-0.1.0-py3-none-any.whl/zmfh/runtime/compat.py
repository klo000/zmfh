"""Compatibility helpers."""

# Reserved for future expansion.
