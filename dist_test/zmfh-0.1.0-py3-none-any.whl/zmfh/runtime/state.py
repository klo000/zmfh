"""Process-local runtime state."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from zmfh.runtime.modes import Mode


@dataclass
class ZMFHState:
    bootstrapped: bool = False
    disabled: bool = False
    diag: bool = False
    mode: Mode = Mode.PASSIVE

    root: Optional[str] = None
    roots: list[str] = field(default_factory=list)
    policy_path: Optional[str] = None

    hook_installed: bool = False
    last_error: Optional[str] = None

    def as_dict(self) -> dict:
        return {
            "bootstrapped": self.bootstrapped,
            "disabled": self.disabled,
            "diag": self.diag,
            "mode": getattr(self.mode, "value", str(self.mode)),
            "root": self.root,
            "roots": list(self.roots) if self.roots else None,
            "policy_path": self.policy_path,
            "hook_installed": self.hook_installed,
            "last_error": self.last_error,
        }


_STATE = ZMFHState()


def get_state() -> ZMFHState:
    return _STATE
